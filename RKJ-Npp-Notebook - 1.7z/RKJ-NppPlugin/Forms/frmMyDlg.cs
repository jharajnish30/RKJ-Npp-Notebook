﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Kbg.NppPluginNET.PluginInfrastructure;
using Kbg.NppPluginNET;

namespace Kbg.NppPluginNET
{
	public partial class frmRKJNppPlugin : Form
	{
		public frmRKJNppPlugin()
		{
			InitializeComponent();
		}

		private void listView1_SelectedIndexChanged(object sender, EventArgs e)
		{

		}

		private void frmRKJNppPlugin_Load(object sender, EventArgs e)
		{
		}

		private void frmRKJNppPlugin_Click(object sender, EventArgs e)
		{
			//MessageBox.Show(Main.ConfigFolder);
			//MessageBox.Show(Main.RootFolder);
			//MessageBox.Show(Main.NotebookFolder);

		}
	}
}